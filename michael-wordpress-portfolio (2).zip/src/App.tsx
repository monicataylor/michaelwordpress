import { useEffect, useMemo, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import {
  ArrowDown, ArrowRight, ArrowUpRight, BadgeCheck, BarChart3, Bot,
  Check, ChevronDown, Code2, Facebook, Gauge, LayoutTemplate, Linkedin,
  LockKeyhole, Mail, Menu, MessageCircle, MonitorSmartphone, PenTool, Search,
  Send, ShieldCheck, Sparkles, X,
} from 'lucide-react'

type Project = { title: string; category: string; type: string; description: string; theme: string; initials: string; image?: string; url?: string; linkLabel?: string }

const navItems = [
  ['Home', '#home'], ['About', '#about'], ['Services', '#services'], ['Portfolio', '#portfolio'],
  ['Pricing', '#pricing'], ['FAQ', '#faq'], ['Contact', '#contact'],
]

const services = [
  { icon: LayoutTemplate, title: 'WordPress Web Design', text: 'A polished, easy-to-navigate website design tailored to your brand, audience, and goals.' },
  { icon: Code2, title: 'Website Development', text: 'Responsive WordPress builds with Elementor Pro, custom functionality, and a clean editing experience.' },
  { icon: Search, title: 'SEO & AI Search Visibility', text: 'A strong technical foundation, structured content, and on-page SEO to help people find your business.' },
  { icon: BarChart3, title: 'Social Media Marketing', text: 'A consistent online presence and practical social content support to help your brand stay visible.' },
  { icon: PenTool, title: 'Graphic Design', text: 'Thoughtful visual assets for websites and digital campaigns, aligned with your brand identity.' },
  { icon: Bot, title: 'AI Chatbot Development', text: 'Helpful conversational experiences that answer common questions and guide visitors to the next step.' },
]

const strengths = [
  { icon: BadgeCheck, title: 'Experience you can rely on', text: 'Six years of hands-on WordPress work, from first page concepts through launch and beyond.' },
  { icon: MonitorSmartphone, title: 'Responsive from the start', text: 'Every layout is planned to feel clear and usable on mobile, tablet, and desktop.' },
  { icon: Gauge, title: 'Performance minded', text: 'Clean builds, considered plugins, and practical optimization for a smoother site experience.' },
  { icon: MessageCircle, title: 'Clear communication', text: 'A collaborative process, straightforward updates, and no mystery about the next step.' },
  { icon: LockKeyhole, title: 'Careful implementation', text: 'Reliable WordPress practices, sensible integrations, and attention to the details that matter.' },
  { icon: BarChart3, title: 'Business focused', text: 'A site should do more than look good. I keep your customers and business goals in view.' },
]

const process = [
  { n: '01', title: 'Discover', text: 'We talk through your goals, audience, content, and what success should look like.' },
  { n: '02', title: 'Design', text: 'I map out the key pages and visual direction so we agree on the experience before the build.' },
  { n: '03', title: 'Build & launch', text: 'Your site is developed, reviewed across screen sizes, refined, and prepared for launch.' },
  { n: '04', title: 'Grow', text: 'After launch, you can keep improving with support, SEO, and new features as you need them.' },
]

const packages = [
  { name: 'Basic', price: '$299', kicker: 'A clear online starting point', features: ['Custom page structure', 'Responsive WordPress build', 'Essential on-page SEO', 'Contact form setup', 'Launch walkthrough'], popular: false },
  { name: 'Premium', price: '$499', kicker: 'For growing businesses', features: ['Everything in Basic', 'More pages & tailored sections', 'Elementor Pro setup', 'Performance & SEO foundations', 'Training and launch support'], popular: true },
  { name: 'Advanced', price: '$999', kicker: 'For stores & custom needs', features: ['Everything in Premium', 'WooCommerce or advanced features', 'Custom integrations', 'Expanded testing & refinement', 'Post-launch support plan'], popular: false },
]

const projects: Project[] = [
  { title: 'Cozy Digz IQ', category: 'Property', type: 'Property management', description: 'A property management and short-term rental intelligence website built for Cozy Digz IQ.', theme: 'property', initials: 'CD', image: '/cozy-digg-iq-hero.webp', url: 'https://cozydigziq.com/', linkLabel: 'Property Management website portfolio' },
  { title: 'Tanger', category: 'Retail', type: 'Retail & outlet shopping', description: 'A retail website connecting visitors with Tanger outlet locations, stores, and current offers.', theme: 'tanger', initials: 'T', url: 'https://www.tanger.com/', linkLabel: 'Retail website portfolio' },
  { title: 'Healthcare website', category: 'Healthcare', type: 'Healthcare', description: 'A healthcare website project featuring clear department navigation and family health information.', theme: 'clinic', initials: 'HC', image: '/healthcare-project.webp', url: 'https://www.floridahealth.gov/', linkLabel: 'Healthcare website portfolio' },
  { title: 'Sam’s Shoes', category: 'E-commerce', type: 'WooCommerce store', description: 'An e-commerce website for Sam’s Shoes, showcasing classic footwear and a clear path to shop the collection.', theme: 'shop', initials: 'SS', image: '/sams-shoes-project.webp', url: 'https://samsshoespgh.com/', linkLabel: 'E-commerce website portfolio' },
]

const faqs = [
  { q: 'What kinds of WordPress websites do you build?', a: 'I work on business websites, service websites, blogs, portfolio sites, and online stores. We’ll choose the right structure and features based on what your business needs.' },
  { q: 'Do you build with Elementor Pro?', a: 'Yes. Elementor Pro is one of the tools I use for flexible, easy-to-manage WordPress websites. I’ll recommend the right setup for your project and explain any licence requirements.' },
  { q: 'Can you set up a WooCommerce store?', a: 'Yes. I can build a WooCommerce storefront, configure products and key store pages, and help set up the checkout experience. Payment-provider and shipping requirements are confirmed during discovery.' },
  { q: 'Can you redesign my current website?', a: 'Absolutely. We can review what is working, what needs to change, and plan a redesign that protects important content and keeps your customers in mind.' },
  { q: 'Will my website be SEO-friendly?', a: 'I build with sound technical and on-page SEO foundations, including structure, metadata, and performance considerations. Rankings depend on many ongoing factors, so I don’t promise specific positions.' },
  { q: 'Do you offer website maintenance?', a: 'Ongoing maintenance can be discussed as part of your project. Support may include WordPress and plugin updates, backups, security checks, and small content changes.' },
  { q: 'Can we work together remotely?', a: 'Yes. I’m based on Lagos Island and work remotely with clients. We can plan meetings and updates around a time that works for both of us.' },
]

const testimonials = [
  { name: 'Jake Wilson', text: "He was awesome to work with and built exactly what we needed. I was looking for a skilled Elementor designer who could take our basic brand direction and turn it into a high end site, and he completely nailed the look. He is a fantastic WordPress designer and a sharp WordPress developer who knows how to make a site look premium while keeping it fast and mobile-responsive. Definitely hiring him again." },
  { name: 'Anthony Warren', text: "I hired Michael for my car valeting & detailing business WordPress project, and he did an excellent job. His communication was great, and he understood exactly what I wanted. He delivered everything as promised, and I highly recommend his services. I would gladly work with him again." },
  { name: 'Francesca Bell', text: "Working with Michael O was a great experience. He understood exactly what I needed, delivered the WordPress site quickly, and kept me updated throughout the process. The work was clean, professional, and exactly what I was looking for. I’d happily work with him again and highly recommend him." },
]

const socials = [
  { label: 'Upwork', href: 'https://www.upwork.com/freelancers/~010de8346ae633e8f7', Icon: UpworkIcon },
  { label: 'Facebook', href: 'https://www.facebook.com/Michaelobinnawordpressdeveloper', Icon: Facebook },
  { label: 'Mail', href: 'mailto:info.michaelwebdesign@gmail.com', Icon: Mail },
  { label: 'LinkedIn', href: 'https://www.linkedin.com/in/michael-obinna-wordpress-developer/', Icon: Linkedin },
  { label: 'TikTok', href: 'https://www.tiktok.com/@michaelobinna.wordpress', Icon: TikTokIcon },
]
const quickLinks = [...socials, { label: 'WhatsApp', href: 'https://wa.me/2348146630935', Icon: MessageCircle }]

function Logo({ footer = false }: { footer?: boolean }) {
  return <a className={`brand ${footer ? 'brand-footer' : ''}`} href="#home" aria-label="Home">
    <img className="brand-image" src="/michael-logo.png" alt="Michael O. logo" />
  </a>
}

function UpworkIcon({ size = 16 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M5.1 5v7.2c0 2.6 1.2 4.1 3.5 4.1s3.6-1.5 3.6-4.1V5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
    <path d="M12.3 19V9.1c0-2.5 1.3-4.1 3.7-4.1s3.8 1.6 3.8 4.1-1.4 4.2-3.8 4.2c-1.8 0-3-.8-3.7-2.3" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
}

function TikTokIcon({ size = 16 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 4v10.5a4.2 4.2 0 1 1-3.4-4.1v3a1.3 1.3 0 1 0 1.1 1.3V4h2.3c.2 1.8 1.2 3 3.2 3.5v2.4c-1.4-.1-2.5-.6-3.2-1.3" stroke="#25f4ee" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" transform="translate(-.8 .3)" />
    <path d="M14 4v10.5a4.2 4.2 0 1 1-3.4-4.1v3a1.3 1.3 0 1 0 1.1 1.3V4h2.3c.2 1.8 1.2 3 3.2 3.5v2.4c-1.4-.1-2.5-.6-3.2-1.3" stroke="#fe2c55" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" transform="translate(.8 -.2)" />
    <path d="M14 4v10.5a4.2 4.2 0 1 1-3.4-4.1v3a1.3 1.3 0 1 0 1.1 1.3V4h2.3c.2 1.8 1.2 3 3.2 3.5v2.4c-1.4-.1-2.5-.6-3.2-1.3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
}

function MockupCard({ project }: { project: Project }) {
  return <div className={`project-preview ${project.theme}`} aria-hidden="true">
    {project.image ? <img src={project.image} alt="" loading="lazy" /> : project.url ? <div className="project-live-content">
      <span>LIVE WEBSITE</span>
      <strong>TANGER</strong>
      <small>tanger.com</small>
    </div> : <div className="project-placeholder-content">
      <span className="project-placeholder-category">{project.category}</span>
      <span className="project-placeholder-rule" />
      <strong>{project.title}</strong>
      <small>Project image to be added</small>
    </div>}
  </div>
}

function App() {
  const [activeFilter, setActiveFilter] = useState('All')
  const [activeProject, setActiveProject] = useState<Project | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [formStatus, setFormStatus] = useState<{ kind: 'success' | 'error'; text: string } | null>(null)
  const [sending, setSending] = useState(false)
  const [selectedService, setSelectedService] = useState('')
  const formStartedAt = useRef(Date.now())
  const filteredProjects = useMemo(() => activeFilter === 'All' ? projects : projects.filter(p => p.category === activeFilter), [activeFilter])
  const filters = ['All']

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target) }
    }), { threshold: 0.1 })
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!activeProject) return
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') setActiveProject(null) }
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = '' }
  }, [activeProject])

  const goToContact = (service = '') => {
    setSelectedService(service)
    document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })
  }

  async function submitContact(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setFormStatus(null)
    const form = event.currentTarget
    const data = new FormData(form)
    const name = String(data.get('name') || '').trim()
    const email = String(data.get('email') || '').trim()
    const phone = String(data.get('phone') || '').trim()
    const service = String(data.get('service') || '').trim()
    const message = String(data.get('message') || '').trim()
    const website = String(data.get('website') || '').trim()

    if (website) { setFormStatus({ kind: 'success', text: 'Thanks — your enquiry has been received.' }); form.reset(); return }
    if (name.length < 2 || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 20 || message.length > 3000) {
      setFormStatus({ kind: 'error', text: 'Please check your name, email address, and message (at least 20 characters).' }); return
    }
    if (Date.now() - formStartedAt.current < 1800) {
      setFormStatus({ kind: 'error', text: 'Please take a moment to review your enquiry and try again.' }); return
    }
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL?.trim()
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim()
    if (!supabaseUrl || !supabaseAnonKey) {
      setFormStatus({ kind: 'error', text: 'The contact form is not connected yet. Please email Michael directly at info.michaelwebdesign@gmail.com.' }); return
    }
    setSending(true)
    try {
      const response = await fetch(`${supabaseUrl.replace(/\/$/, '')}/functions/v1/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: supabaseAnonKey, Authorization: `Bearer ${supabaseAnonKey}` },
        body: JSON.stringify({ name, email, phone, service, message, website, elapsedMs: Date.now() - formStartedAt.current }),
      })
      const result = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(result.error || 'Could not send your message. Please email Michael directly.')
      setFormStatus({ kind: 'success', text: 'Thanks — your enquiry has been sent. Michael will be in touch soon.' })
      form.reset()
      setSelectedService('')
      formStartedAt.current = Date.now()
    } catch (error) {
      setFormStatus({ kind: 'error', text: error instanceof Error ? error.message : 'Something went wrong. Please try again or email Michael directly.' })
    } finally { setSending(false) }
  }

  return <div className="site-shell">
    <header className="site-header">
      <div className="container nav-wrap">
        <Logo />
        <button className="mobile-toggle" aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'main-nav open' : 'main-nav'} aria-label="Main navigation">
          {navItems.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}</a>)}
          <a className="nav-cta" href="#contact" onClick={() => setMenuOpen(false)}>Let’s Talk <ArrowUpRight size={15} /></a>
        </nav>
      </div>
    </header>

    <main>
      <section className="hero section-pad" id="home">
        <div className="hero-glow" />
        <div className="container hero-grid">
          <div className="hero-copy reveal">
            <div className="eyebrow"><span className="eyebrow-dot" /> Available for select projects <span className="eyebrow-divider">—</span> Lagos Island</div>
            <h1>Websites built to<br /><span>move business</span><br />forward.</h1>
            <p className="hero-intro">I’m <strong>Michael O.</strong>, a Senior WordPress Developer. I create professional websites that help ambitious businesses attract customers, build trust, and grow online.</p>
            <div className="hero-actions"><a className="button button-primary" href="#contact">Let’s Work Together <ArrowUpRight size={17} /></a><a className="button button-quiet" href="#portfolio">View My Work <ArrowDown size={15} /></a></div>
            <div className="hero-proof"><div className="experience-mark"><b>6</b><span>YEARS<br />EXPERIENCE</span></div><span className="proof-line" /><span className="proof-copy">Thoughtful WordPress development<br />for the next stage of your business.</span></div>
          </div>
          <div className="hero-visual reveal reveal-delay-1">
            <figure className="featured-project"><div className="featured-project-image"><img src="/cozy-digg-iq-hero.webp" alt="Hero section of the Cozy Digz IQ property management website built by Michael." loading="eager" /></div><figcaption className="featured-project-caption"><div><span>SELECTED PROJECT</span><strong>Cozy Digz IQ</strong><small>Property management · WordPress</small></div><a href="#portfolio" aria-label="See Cozy Digz IQ in the portfolio"><ArrowUpRight size={17} /></a></figcaption></figure>
          </div>
        </div>
        <div className="container hero-bottom"><span>BUILT FOR BUSINESS</span><span className="hero-bottom-line" /><span>WORDPRESS · ELEMENTOR · WOOCOMMERCE</span></div>
      </section>

      <section className="value-strip"><div className="container value-grid">
        <article className="value-item reveal"><span className="value-icon"><BarChart3 /></span><div><h3>Websites Built to Convert.</h3><p>Clear journeys that make it easier for the right customers to take action.</p></div></article>
        <article className="value-item reveal reveal-delay-1"><span className="value-icon"><Gauge /></span><div><h3>Fast, Responsive & SEO-Friendly.</h3><p>Carefully built for a smoother experience across devices and search.</p></div></article>
        <article className="value-item reveal reveal-delay-2"><span className="value-icon"><Code2 /></span><div><h3>Professional WordPress Development.</h3><p>Flexible, manageable websites built with dependable WordPress tools.</p></div></article>
      </div></section>

      <section className="about-section section-pad" id="about"><div className="container about-grid">
        <div className="about-art reveal"><figure className="about-photo-card"><img className="about-portrait" src="/michael-profile.webp" alt="Portrait of Michael O., Senior WordPress Developer." loading="lazy" /><figcaption className="about-photo-caption"><div><strong>Michael O.</strong><span>Senior WordPress Developer</span></div><small>Lagos Island · 6 years</small></figcaption></figure></div>
        <div className="about-copy reveal reveal-delay-1"><div className="section-kicker">A little about me</div><h2>Strategy-minded.<br /><span>Detail-driven.</span></h2><p>I’m Michael, a Senior WordPress Developer based on Lagos Island. With a Computer Science background and six years of experience, I bring technical thinking and practical creativity to every build.</p><p>I help businesses establish a stronger online presence with websites that look professional, work smoothly, and make it easy for customers to understand what you do. From Elementor Pro builds to WooCommerce and custom WordPress functionality, I care about both the details and the bigger business goal.</p><div className="about-tags"><span><Check size={13} /> Computer Science background</span><span><Check size={13} /> 6 years in WordPress</span><span><Check size={13} /> Lagos Island</span></div><a className="text-link" href="#contact">More about working together <ArrowRight size={15} /></a></div>
      </div></section>

      <section className="services-section section-pad" id="services"><div className="container"><div className="section-heading reveal"><div><div className="section-kicker">What I do</div><h2>Digital solutions for<br /><span>real business goals.</span></h2></div><p>From a strong first impression to the technology that powers it, I can help bring your next digital project to life.</p></div><div className="services-grid">{services.map((service, index) => { const Icon = service.icon; return <article className={`service-card reveal reveal-delay-${index % 3}`} key={service.title}><div className="service-top"><span className="service-icon"><Icon size={19} /></span><span className="service-index">0{index + 1}</span></div><h3>{service.title}</h3><p>{service.text}</p><button className="service-link" onClick={() => goToContact(service.title)}>Enquire about this <ArrowUpRight size={14} /></button></article> })}</div></div></section>

      <section className="why-section section-pad"><div className="container why-grid"><div className="why-copy reveal"><div className="section-kicker">Why work with me</div><h2>Good development<br />is a <span>business tool.</span></h2><p>I combine technical expertise with a clear, collaborative process to deliver work that supports your business—not just the brief.</p><a className="button button-primary" href="#contact">Let’s discuss your project <ArrowUpRight size={16} /></a><div className="years-box"><strong>06<span>+</span></strong><div><b>Years of WordPress experience</b><small>Practical skills. Thoughtful execution.</small></div></div></div><div className="strength-grid">{strengths.map((item, index) => { const Icon = item.icon; return <article className={`strength-card reveal reveal-delay-${index % 3}`} key={item.title}><span className="strength-icon"><Icon size={18} /></span><h3>{item.title}</h3><p>{item.text}</p></article> })}</div></div></section>

      <section className="process-section section-pad"><div className="container"><div className="section-heading process-heading reveal"><div><div className="section-kicker">A clear path from idea to launch</div><h2>Good work starts with<br /><span>a good process.</span></h2></div><p>Collaborative, transparent, and focused on getting your project to the right outcome.</p></div><div className="process-grid">{process.map((step, index) => <article className={`process-card reveal reveal-delay-${index}`} key={step.n}><div className="process-number">{step.n}<span>{index < process.length - 1 && <ArrowRight size={14} />}</span></div><h3>{step.title}</h3><p>{step.text}</p></article>)}</div></div></section>

      <section className="pricing-section section-pad" id="pricing"><div className="container"><div className="section-heading pricing-heading reveal"><div><div className="section-kicker">Straightforward options</div><h2>Start with the right<br /><span>level of support.</span></h2></div><p>Choose the package that fits your project. We’ll confirm the deliverables and scope with you before work begins.</p></div><div className="pricing-grid">{packages.map((pkg, index) => <article className={`price-card reveal reveal-delay-${index} ${pkg.popular ? 'price-featured' : ''}`} key={pkg.name}>{pkg.popular && <div className="popular-label"><Sparkles size={12} /> MOST REQUESTED</div>}<div className="price-topline"><span className="price-tier">0{index + 1} / PACKAGE</span><span className="price-icon"><ArrowUpRight size={17} /></span></div><h3>{pkg.name}</h3><p className="price-kicker">{pkg.kicker}</p><div className="price-placeholder">{pkg.price}</div><p className="price-note">Package price · scope confirmed before work begins</p><div className="price-divider" /><ul>{pkg.features.map((feature, i) => <li key={i}><Check size={14} />{feature}</li>)}</ul><button className={pkg.popular ? 'button button-primary price-button' : 'button button-outline price-button'} onClick={() => goToContact(`${pkg.name} package`)}>Discuss this package <ArrowUpRight size={15} /></button></article>)}</div><p className="pricing-footnote"><ShieldCheck size={15} /> Package details can be confirmed before work begins.</p></div></section>

      <section className="portfolio-section section-pad" id="portfolio"><div className="container"><div className="section-heading portfolio-heading reveal"><div><div className="section-kicker">Portfolio</div><h2>Built for different<br /><span>kinds of business.</span></h2></div><p>Selected projects and a few portfolio slots for work being added. Each project opens with its details.</p></div><div className="portfolio-filters" role="group" aria-label="Filter portfolio projects">{filters.map(filter => <button key={filter} className={activeFilter === filter ? 'filter-chip active' : 'filter-chip'} onClick={() => setActiveFilter(filter)}>{filter === 'All' ? 'Projects' : filter}</button>)}</div><div className="portfolio-grid">{filteredProjects.map((project, index) => <article className={`portfolio-card reveal reveal-delay-${index % 3}`} key={project.title}><button className="project-open" onClick={() => setActiveProject(project)} aria-label={`View ${project.title} project details`}><MockupCard project={project} /><span className="project-overlay"><span>VIEW PROJECT NOTES <ArrowUpRight size={15} /></span></span></button><div className="portfolio-info"><div><span className="portfolio-type">{project.category}</span><h3>{project.title}</h3></div><button className="round-arrow" onClick={() => setActiveProject(project)} aria-label={`View ${project.title} details`}><ArrowUpRight size={17} /></button></div></article>)}</div><div className="portfolio-more"><a className="button button-outline" href="#contact">Want to see more past projects? Send a message <ArrowRight size={15} /></a></div></div></section>

      <section className="testimonial-section section-pad"><div className="container"><div className="section-heading testimonial-heading reveal"><div><div className="section-kicker">Client feedback</div><h2>Good partnerships<br /><span>make great work.</span></h2></div><p>A few words shared by clients after working together.</p></div><div className="testimonial-grid">{testimonials.map((testimonial, index) => <article className={`testimonial-card reveal reveal-delay-${index}`} key={index}><div className="quote-mark">“</div><p>{testimonial.text}</p><div className="testimonial-person"><span className="person-avatar"><MessageCircle size={13} /></span><span><b>{testimonial.name}</b></span></div></article>)}</div></div></section>

      <section className="faq-section section-pad" id="faq"><div className="container faq-grid"><div className="faq-intro reveal"><div className="section-kicker">A few answers</div><h2>Questions before<br /><span>we get started?</span></h2><p>Here are a few things people often ask. If you have something else in mind, just reach out.</p><a className="text-link" href="#contact">Ask me directly <ArrowRight size={15} /></a><div className="faq-chat"><MessageCircle size={19} /><span><b>Prefer WhatsApp?</b><small>Send a quick message</small></span><a href="https://wa.me/2348146630935" target="_blank" rel="noreferrer" aria-label="Chat with Michael on WhatsApp"><ArrowUpRight size={15} /></a></div></div><div className="faq-list reveal reveal-delay-1">{faqs.map((faq, index) => <details className="faq-item" key={faq.q} open={index === 0}><summary><span>{faq.q}</span><ChevronDown size={17} /></summary><p>{faq.a}</p></details>)}</div></div></section>

      <section className="contact-section section-pad" id="contact"><div className="contact-orb" /><div className="container contact-grid"><div className="contact-copy reveal"><div className="section-kicker">Let’s work together</div><h2>Ready to build a website that works <span>harder for you?</span></h2><p>Tell me what you’re working on. I’ll reply personally so we can talk about your goals, your timeline, and the next steps.</p><div className="contact-methods"><a href="mailto:info.michaelwebdesign@gmail.com"><span><Mail size={16} /></span><div><small>EMAIL ME</small><b>info.michaelwebdesign@gmail.com</b></div><ArrowUpRight size={15} /></a><a href="https://wa.me/2348146630935" target="_blank" rel="noreferrer"><span className="whatsapp-icon"><MessageCircle size={16} /></span><div><small>WHATSAPP</small><b>+234 814 663 0935</b></div><ArrowUpRight size={15} /></a></div><div className="social-row">{socials.map(({ label, href, Icon }) => <a key={label} href={href} target={label === 'Mail' ? undefined : '_blank'} rel={label === 'Mail' ? undefined : 'noreferrer'} aria-label={label}><Icon size={18} /></a>)}</div></div>
          <form className="contact-form reveal reveal-delay-1" onSubmit={submitContact} noValidate><div className="form-heading"><span>PROJECT ENQUIRY</span><span className="form-required">* Required</span></div><div className="form-row"><label>Your name *<input name="name" autoComplete="name" placeholder="e.g. Ada Okafor" minLength={2} maxLength={100} required /></label><label>Email address *<input name="email" type="email" autoComplete="email" placeholder="you@company.com" required /></label></div><div className="form-row"><label>Phone / WhatsApp<input name="phone" type="tel" autoComplete="tel" placeholder="+234 …" maxLength={40} /></label><label>What do you need?<select name="service" value={selectedService} onChange={e => setSelectedService(e.target.value)}><option value="">Choose a service</option>{services.map(s => <option key={s.title} value={s.title}>{s.title}</option>)}{packages.map(p => <option key={p.name} value={`${p.name} package`}>{p.name} package</option>)}<option value="Something else">Something else</option></select></label></div><label className="message-label">Tell me about your project *<textarea name="message" placeholder="A little about your business, goals, and what you have in mind…" minLength={20} maxLength={3000} rows={4} required /></label><label className="honeypot" aria-hidden="true">Leave this field empty<input name="website" tabIndex={-1} autoComplete="off" /></label><div className="form-foot"><span><LockKeyhole size={13} /> Your details are only used to reply to this enquiry.</span><button className="button button-primary" type="submit" disabled={sending}>{sending ? <><span className="spinner" /> Sending…</> : <>Send enquiry <Send size={15} /></>}</button></div>{formStatus && <div className={`form-alert ${formStatus.kind}`} role={formStatus.kind === 'error' ? 'alert' : 'status'}>{formStatus.kind === 'success' ? <Check size={15} /> : <X size={15} />}{formStatus.text}</div>}</form>
        </div></section>
    </main>

    <footer className="site-footer"><div className="container"><div className="footer-top"><div className="footer-brand-col"><Logo footer /><p>Thoughtful WordPress development<br />for businesses ready to grow.</p><span className="footer-location"><span className="location-dot" /> Lagos Island</span></div><div className="footer-nav-col"><b>EXPLORE</b><a href="#about">About</a><a href="#services">Services</a><a href="#portfolio">Portfolio</a><a href="#pricing">Pricing</a></div><div className="footer-nav-col"><b>GET IN TOUCH</b><a href="mailto:info.michaelwebdesign@gmail.com">Email Michael</a><a href="https://wa.me/2348146630935" target="_blank" rel="noreferrer">WhatsApp</a><a href="#faq">FAQs</a><a href="#contact">Start a project</a></div><div className="footer-connect"><b>CONNECT WITH ME</b><div>{socials.map(({ label, href, Icon }) => <a key={label} href={href} aria-label={label} target={label === 'Mail' ? undefined : '_blank'} rel={label === 'Mail' ? undefined : 'noreferrer'}><Icon size={16} /></a>)}</div><a href="#contact" className="footer-cta">Have a project in mind? <ArrowUpRight size={14} /></a></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} Michael O. All rights reserved.</span><span>Designed & developed with care <span className="footer-heart">✳</span></span><a href="#home">Back to top ↑</a></div></div></footer>

    {activeProject && <div className="modal-backdrop" role="presentation" onClick={() => setActiveProject(null)}><div className="project-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setActiveProject(null)} aria-label="Close project details"><X size={18} /></button><MockupCard project={activeProject} /><div className="modal-copy"><span className="portfolio-type">{activeProject.category} / {activeProject.image || activeProject.url ? 'FEATURED BUILD' : 'PROJECT PLACEHOLDER'}</span><h2 id="modal-title">{activeProject.title}</h2><p>{activeProject.description}</p>{activeProject.url ? <a className="modal-note modal-project-link" href={activeProject.url} target="_blank" rel="noreferrer"><ArrowUpRight size={14} />{activeProject.linkLabel || 'View project website'}</a> : <div className="modal-note"><LockKeyhole size={14} />{activeProject.image ? 'Add a live website URL and fuller case study when available.' : 'Replace this project placeholder with an approved screenshot, project details, and live link.'}</div>}<button className="button button-primary" onClick={() => { setActiveProject(null); goToContact(activeProject.title) }}>Discuss a similar project <ArrowUpRight size={15} /></button></div></div></div>}
    <nav className="quick-links-float" aria-label="Quick links">{quickLinks.map(({ label, href, Icon }) => <a key={label} className={`quick-icon quick-${label.toLowerCase()}`} href={href} aria-label={label} target={href.startsWith('mailto:') ? undefined : '_blank'} rel={href.startsWith('mailto:') ? undefined : 'noreferrer'}><Icon size={18} /></a>)}</nav>
  </div>
}

export default App
