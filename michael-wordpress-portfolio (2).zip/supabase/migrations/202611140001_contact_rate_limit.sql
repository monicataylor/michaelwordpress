create table if not exists public.contact_rate_limits (
  ip_hash text primary key,
  window_started_at timestamptz not null default now(),
  request_count integer not null default 0
);

alter table public.contact_rate_limits enable row level security;
revoke all on table public.contact_rate_limits from anon, authenticated, public;

grant usage on schema public to service_role;
grant select, insert, update, delete on table public.contact_rate_limits to service_role;

create or replace function public.check_contact_rate_limit(p_ip_hash text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  current_count integer;
begin
  insert into public.contact_rate_limits (ip_hash, window_started_at, request_count)
  values (p_ip_hash, now(), 1)
  on conflict (ip_hash) do update set
    window_started_at = case
      when public.contact_rate_limits.window_started_at < now() - interval '1 hour' then now()
      else public.contact_rate_limits.window_started_at
    end,
    request_count = case
      when public.contact_rate_limits.window_started_at < now() - interval '1 hour' then 1
      else public.contact_rate_limits.request_count + 1
    end;

  select request_count into current_count
  from public.contact_rate_limits where ip_hash = p_ip_hash;

  return current_count <= 5;
end;
$$;

revoke all on function public.check_contact_rate_limit(text) from public, anon, authenticated;
grant execute on function public.check_contact_rate_limit(text) to service_role;
