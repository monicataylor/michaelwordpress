const TO_EMAIL = 'info.michaelwebdesign@gmail.com'
const MAX_MESSAGE = 3000
const MIN_MESSAGE = 20
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const encoder = new TextEncoder()

function json(body: Record<string, unknown>, status: number, headers: HeadersInit = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...headers } })
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]!)
}

async function sha256(value: string) {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(value))
  return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, '0')).join('')
}

Deno.serve(async (request: Request) => {
  const origin = request.headers.get('origin') || ''
  const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN') || ''
  const developmentOrigins = ['http://localhost:5173', 'http://127.0.0.1:5173']
  const originAllowed = origin === allowedOrigin || developmentOrigins.includes(origin)
  const corsHeaders = {
    'Access-Control-Allow-Origin': originAllowed ? origin : allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin',
  }

  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (!originAllowed) return json({ error: 'Origin not allowed.' }, 403, corsHeaders)
  if (request.method !== 'POST') return json({ error: 'Method not allowed.' }, 405, corsHeaders)
  const length = Number(request.headers.get('content-length') || '0')
  if (length > 12_000) return json({ error: 'Request is too large.' }, 413, corsHeaders)

  const resendKey = Deno.env.get('RESEND_API_KEY')
  const sender = Deno.env.get('RESEND_FROM')
  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const pepper = Deno.env.get('RATE_LIMIT_PEPPER')
  if (!resendKey || !sender || !supabaseUrl || !serviceRoleKey || !pepper) {
    console.error('Contact function missing one or more required secrets.')
    return json({ error: 'The contact service is not fully configured yet. Please email Michael directly.' }, 503, corsHeaders)
  }

  let body: Record<string, unknown>
  try { body = await request.json() } catch { return json({ error: 'Please submit a valid enquiry.' }, 400, corsHeaders) }
  const name = typeof body.name === 'string' ? body.name.trim() : ''
  const email = typeof body.email === 'string' ? body.email.trim() : ''
  const phone = typeof body.phone === 'string' ? body.phone.trim() : ''
  const service = typeof body.service === 'string' ? body.service.trim() : ''
  const message = typeof body.message === 'string' ? body.message.trim() : ''
  const honeypot = typeof body.website === 'string' ? body.website.trim() : ''
  const elapsedMs = Number(body.elapsedMs || 0)

  // Quietly accept bot traps so automated form fillers do not learn the detection rule.
  if (honeypot) return json({ ok: true }, 200, corsHeaders)
  if (name.length < 2 || name.length > 100 || !emailPattern.test(email) || email.length > 254 || message.length < MIN_MESSAGE || message.length > MAX_MESSAGE || phone.length > 40 || service.length > 120) {
    return json({ error: 'Please check your details and message, then try again.' }, 400, corsHeaders)
  }
  if (!Number.isFinite(elapsedMs) || elapsedMs < 1500) return json({ error: 'Please take a moment to review your enquiry and try again.' }, 400, corsHeaders)

  const clientIp = request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown'
  const ipHash = await sha256(`${clientIp}:${pepper}`)
  try {
    const rateResponse = await fetch(`${supabaseUrl.replace(/\/$/, '')}/rest/v1/rpc/check_contact_rate_limit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` },
      body: JSON.stringify({ p_ip_hash: ipHash }),
    })
    if (!rateResponse.ok) {
      console.error('Rate-limit check failed:', await rateResponse.text())
      return json({ error: 'The contact service is temporarily unavailable. Please email Michael directly.' }, 503, corsHeaders)
    }
    const withinLimit = await rateResponse.json()
    if (withinLimit !== true) return json({ error: 'Too many enquiries from this connection. Please try again later or email Michael directly.' }, 429, corsHeaders)
  } catch (error) {
    console.error('Rate-limit service error:', error)
    return json({ error: 'The contact service is temporarily unavailable. Please email Michael directly.' }, 503, corsHeaders)
  }

  const safeName = escapeHtml(name)
  const safeEmail = escapeHtml(email)
  const safePhone = escapeHtml(phone || 'Not provided')
  const safeService = escapeHtml(service || 'Not specified')
  const safeMessage = escapeHtml(message).replace(/\r?\n/g, '<br>')
  const text = `New portfolio enquiry\n\nName: ${name}\nEmail: ${email}\nPhone / WhatsApp: ${phone || 'Not provided'}\nService: ${service || 'Not specified'}\n\nMessage:\n${message}`

  try {
    const mailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: sender,
        to: [TO_EMAIL],
        reply_to: email,
        subject: `Portfolio enquiry from ${name}`,
        text,
        html: `<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;color:#172033"><h2 style="color:#315de8">New website project enquiry</h2><p><b>Name:</b> ${safeName}</p><p><b>Email:</b> ${safeEmail}</p><p><b>Phone / WhatsApp:</b> ${safePhone}</p><p><b>Service:</b> ${safeService}</p><hr style="border:0;border-top:1px solid #dce2ed"><p><b>Project details</b></p><p style="line-height:1.7">${safeMessage}</p></div>`,
      }),
    })
    if (!mailResponse.ok) {
      console.error('Resend API returned an error:', await mailResponse.text())
      return json({ error: 'We could not send your enquiry right now. Please try again or email Michael directly.' }, 502, corsHeaders)
    }
    return json({ ok: true }, 200, corsHeaders)
  } catch (error) {
    console.error('Resend request failed:', error)
    return json({ error: 'We could not send your enquiry right now. Please try again or email Michael directly.' }, 502, corsHeaders)
  }
})
