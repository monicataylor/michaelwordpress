# Michael O. — WordPress Developer Portfolio

Responsive React + TypeScript + Vite portfolio with Tailwind CSS, Lucide icons, a single-tab project gallery, FAQ accordions, contact shortcuts, Upwork/social links, and a secure Supabase Edge Function + Resend email integration.

## Local preview

```bash
npm install
cp .env.example .env.local
npm run dev
```

The site can be explored without Supabase credentials. Until the backend is configured, the contact form deliberately shows a setup notice and provides Michael’s direct email; it never pretends an email was delivered.

## Configure genuine contact email delivery

1. Create a Supabase project and a Resend account. Verify a domain in Resend and configure the sender address on that verified domain.
2. Set the private Edge Function secrets (never add these to a `VITE_` variable or browser code):

   ```bash
   supabase secrets set RESEND_API_KEY=re_... \
     RESEND_FROM='Michael O. <website@your-verified-domain.com>' \
     SUPABASE_URL='https://YOUR_PROJECT_REF.supabase.co' \
     SUPABASE_SERVICE_ROLE_KEY='YOUR_SERVICE_ROLE_KEY' \
     ALLOWED_ORIGIN='https://your-live-site.example' \
     RATE_LIMIT_PEPPER='a-long-random-secret'
   ```

3. Apply the rate-limit migration and deploy the Edge Function:

   ```bash
   supabase link --project-ref YOUR_PROJECT_REF
   supabase db push
   supabase functions deploy contact
   ```

4. Copy the **project URL** and **anon/publishable key** to `.env.local` as `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. These two browser values are public project configuration; the Resend API key and Supabase service-role key remain exclusively in Edge Function secrets. Restart Vite after updating the env file.
5. In Supabase, confirm the contact Edge Function is deployed with JWT verification enabled. The site sends the anon key as its bearer token; the function sends mail through Resend to `info.michaelwebdesign@gmail.com`.
6. Test a real submission on the deployed domain and verify delivery and reply-to behavior in Resend. Add your local origin (for example `http://localhost:5173`) to the function's accepted development origins while testing locally; remove it for production if not needed.

The Edge Function validates fields, checks a hidden honeypot and minimum completion time, rate-limits hashed IP addresses to five attempts per hour using the included database migration, and sends escaped HTML/plain-text email. Only the contact details required to reply are emailed. Configure `ALLOWED_ORIGIN` to the exact deployed site origin.

## Editing content

- Update service, package, FAQ, portfolio, and testimonial data arrays at the top of `src/App.tsx`.
- The Cozy Digz IQ project uses Michael’s supplied website screenshot. Other portfolio categories are clearly marked screenshot placeholders; replace them with real project images, summaries, and authorized live URLs as work is added.
- The three supplied client testimonials are displayed with their provided names: Jake Wilson, Anthony Warren, and Francesca Bell.
- Package prices are editable in `src/App.tsx`: Basic $299, Premium $499, Advanced $999.
- Replace the brand/logo or contact details in `src/App.tsx` and `public/` as needed.

## Build

```bash
npm run build
```
