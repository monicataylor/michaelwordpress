/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: { colors: { midnight: '#080e1b', electric: '#3567ff', ice: '#eff4ff' } } },
  plugins: [],
}
